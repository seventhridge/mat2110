flyingturtlemove
#how the flying turtle moves
newenemyturtle
#spawn new enemy turtles
enemyturtlemove
#move enemy turtles
gameloop
#main loop of the game
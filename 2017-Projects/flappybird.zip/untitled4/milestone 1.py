


def flyingturtlemove():
    #gravity

    #how the flying turtle moves

def fn_up():
    #Make turtle jump

def newenemyturtle():
#spawn 2 new enemy turtles (one 20 above the other
#send turtles to the left at a constant speed

def gameloop():
#main loop of the game